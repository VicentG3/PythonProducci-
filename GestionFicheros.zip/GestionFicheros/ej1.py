import os

os.mkdir("imatge")
os.mkdir("documents")
os.mkdir("altres")